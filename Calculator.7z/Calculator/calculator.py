num1=int(input("Enter the first number: "))
num2=int(input("Enter the Second number: "))
opr=input("Enter the operation: ")
if opr=="+":
    print(num1+num2)
elif opr=="-":
    print(num1-num2)
elif opr=="*":
    print(num1*num2)
elif opr=="/":
    print(num1/num2)
else:
    print("Invalid input")